﻿
Partial Class receipt
    Inherits System.Web.UI.Page

End Class
